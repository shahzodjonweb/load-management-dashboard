export const VUE_APP_API_URL = "https://api.shipio.app/api";
export const VUE_APP_GOOGLE_TOKEN =
  "1021835190205-pagkgp5e2me6doo0uh1bvfage6ck0qb1.apps.googleusercontent.com";
export const STORAGE_KEY = "_easy_move_key_";
export const GOOGLE_GEOCODING_API_KEY =
  "AIzaSyA2b82nOOXYn8LIjMiqQtV1jhM9wVj4q3E";
