<template>
  <v-app>
    <v-main>
      <Nuxt />
    </v-main>
    <VuetifyToast ref="toast" />
  </v-app>
</template>
